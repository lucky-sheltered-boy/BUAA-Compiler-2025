package frontend.Visitor.Symbol;

public enum SymbolType {
    ConstInt,
    ConstIntArray,
    Int,
    IntArray,
    StaticInt,
    StaticIntArray,
    VoidFunc,
    IntFunc,
}

