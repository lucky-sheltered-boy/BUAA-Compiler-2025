package frontend.parser.AST.Exp.PrimaryExp;

import frontend.parser.Node;

public interface PrimaryExp extends Node {
}
