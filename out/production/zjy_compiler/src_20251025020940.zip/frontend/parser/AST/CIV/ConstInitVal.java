package frontend.parser.AST.CIV;

import frontend.parser.Node;

public interface ConstInitVal extends Node {
}
