package frontend.parser;

public interface Node {
}
