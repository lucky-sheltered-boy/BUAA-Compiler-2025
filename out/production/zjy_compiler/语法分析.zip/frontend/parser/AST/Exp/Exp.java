package frontend.parser.AST.Exp;

import frontend.parser.Node;

public class Exp implements Node {
    private AddExp addExp;

    // Exp → AddExp
    public Exp(AddExp addExp) {
        this.addExp = addExp;
    }

    public AddExp getAddExp() {
        return addExp;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(addExp.toString());
        sb.append("<Exp>\n");
        return sb.toString();
    }
}
