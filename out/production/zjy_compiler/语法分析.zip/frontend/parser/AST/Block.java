package frontend.parser.AST;

import frontend.parser.Node;

import java.util.ArrayList;

public class Block implements Node {
    private ArrayList<BlockItem> blockItems;

    // Block → '{' { BlockItem } '}'
    public Block(ArrayList<BlockItem> blockItems) {
        this.blockItems = blockItems;
    }

    public ArrayList<BlockItem> getBlockItems() {
        return blockItems;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("LBRACE {\n");
        for (BlockItem item : blockItems) {
            sb.append(item.toString());
        }
        sb.append("RBRACE }\n");
        sb.append("<Block>\n");
        return sb.toString();
    }
}
