package frontend.parser.AST.IV;

import frontend.parser.Node;

public interface InitVal extends Node {
}
