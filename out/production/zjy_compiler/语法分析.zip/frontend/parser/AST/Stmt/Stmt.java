package frontend.parser.AST.Stmt;

import frontend.parser.Node;

public interface Stmt extends Node {
}
