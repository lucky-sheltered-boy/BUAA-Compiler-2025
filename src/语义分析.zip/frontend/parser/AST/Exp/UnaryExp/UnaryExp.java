package frontend.parser.AST.Exp.UnaryExp;

import frontend.parser.Node;

public interface UnaryExp extends Node {
}
