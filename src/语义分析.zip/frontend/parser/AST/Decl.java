package frontend.parser.AST;

import frontend.parser.Node;

public interface Decl extends Node {
}
